# 2024-06-09T14:50:29.518519200
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/hls_prj")

vitis.dispose()

